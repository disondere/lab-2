﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using Microsoft.Win32;  // Это нужный using для OpenFileDialog

namespace EnemyEditor
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Your save logic here
        }

        private void LoadButton_Click(object sender, RoutedEventArgs e)
        {
            // Your load logic here
        }

        private void LoadIconsButton_Click(object sender, RoutedEventArgs e)
        {
            // Default folder path logic
            string defaultPath = "C:\\Icons";
            LoadIcons(defaultPath);
        }

        private void SelectFolderButton_Click(object sender, RoutedEventArgs e)
        {
            using (var dialog = new System.Windows.Forms.FolderBrowserDialog())
            {
                System.Windows.Forms.DialogResult result = dialog.ShowDialog();
                if (result == System.Windows.Forms.DialogResult.OK && !string.IsNullOrWhiteSpace(dialog.SelectedPath))
                {
                    LoadIcons(dialog.SelectedPath);
                }
                else
                {
                    System.Windows.MessageBox.Show("No folder was selected.");
                }
            }
        }

        private void LoadIcons(string folderPath)
        {
            if (!Directory.Exists(folderPath))
            {
                System.Windows.MessageBox.Show("The specified folder does not exist.");
                return;
            }

            IconsPanel.Children.Clear();
            string[] files = Directory.GetFiles(folderPath, "*.png");
            foreach (string file in files)
            {
                var image = new Image
                {
                    Source = new BitmapImage(new Uri(file)),
                    Width = 50,
                    Height = 50,
                    Margin = new Thickness(5)
                };
                IconsPanel.Children.Add(image);
            }
        }

        private void AddEnemyButton_Click(object sender, RoutedEventArgs e)
        {
            // Открыть диалоговое окно для выбора изображения
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg";
            if (openFileDialog.ShowDialog() == true)
            {
                // Получить путь к выбранному файлу изображения
                string selectedFilePath = openFileDialog.FileName;

                // Создать изображение и установить путь как источник
                var image = new Image
                {
                    Source = new BitmapImage(new Uri(selectedFilePath)),
                    Width = 50,
                    Height = 50,
                    Margin = new Thickness(5)
                };

                // Добавить изображение в панель
                IconsPanel.Children.Add(image);
            }
        }

        private void RemoveEnemyButton_Click(object sender, RoutedEventArgs e)
        {
            // Your remove enemy logic here
        }
    }
}
